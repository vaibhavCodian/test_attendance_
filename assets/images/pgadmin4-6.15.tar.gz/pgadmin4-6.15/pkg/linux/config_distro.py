HELP_PATH = '../../../share/docs/en_US/html/'
DEFAULT_BINARY_PATHS = {
    'pg':   '/usr/bin',
    'ppas': ''
}
