CREATE EXTENSION sslinfo
    SCHEMA test_extension_schema
    VERSION "1.2";
