ALTER SERVER "FS_$%{}[]()&*^!@""'`\/#"
    OPTIONS (DROP host, DROP dbname, DROP port);

REVOKE ALL ON FOREIGN SERVER "FS_$%{}[]()&*^!@""'`\/#" FROM PUBLIC;
