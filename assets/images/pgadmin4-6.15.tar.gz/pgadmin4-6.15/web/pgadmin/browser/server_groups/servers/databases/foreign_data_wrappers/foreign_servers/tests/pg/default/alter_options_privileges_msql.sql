ALTER SERVER "FS_$%{}[]()&*^!@""'`\/#"
    OPTIONS (ADD host '192.168.1.1', ADD dbname 'edb', ADD port '5450');

GRANT USAGE ON FOREIGN SERVER "FS_$%{}[]()&*^!@""'`\/#" TO PUBLIC;
