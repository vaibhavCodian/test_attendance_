-- Extension: sslinfo

-- DROP EXTENSION sslinfo;

CREATE EXTENSION IF NOT EXISTS sslinfo
    SCHEMA test_extension_schema
    VERSION "1.2";
