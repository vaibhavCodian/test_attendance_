ALTER USER MAPPING FOR enterprisedb SERVER test_fs_for_user_mapping
    OPTIONS (SET "user" 'test_user12', SET password 'secret123');
