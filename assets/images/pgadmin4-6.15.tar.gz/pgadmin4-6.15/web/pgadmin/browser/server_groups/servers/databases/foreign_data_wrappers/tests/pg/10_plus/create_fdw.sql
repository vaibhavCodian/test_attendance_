-- Foreign Data Wrapper: Fdw1_$%{}[]()&*^!@"'`\/#

-- DROP FOREIGN DATA WRAPPER IF EXISTS "Fdw1_$%{}[]()&*^!@""'`\/#"

CREATE FOREIGN DATA WRAPPER "Fdw1_$%{}[]()&*^!@""'`\/#";

ALTER FOREIGN DATA WRAPPER "Fdw1_$%{}[]()&*^!@""'`\/#"
    OWNER TO <OWNER>;
