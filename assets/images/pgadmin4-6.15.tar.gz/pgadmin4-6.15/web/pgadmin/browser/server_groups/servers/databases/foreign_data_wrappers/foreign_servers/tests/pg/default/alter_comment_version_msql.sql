ALTER SERVER "FS_$%{}[]()&*^!@""'`\/#"
    VERSION 1.1;

COMMENT ON SERVER "FS_$%{}[]()&*^!@""'`\/#"
    IS 'Test comment';
