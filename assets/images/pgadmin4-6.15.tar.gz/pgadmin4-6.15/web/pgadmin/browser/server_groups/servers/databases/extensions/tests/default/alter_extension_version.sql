-- Extension: adminpack

-- DROP EXTENSION adminpack;

CREATE EXTENSION IF NOT EXISTS adminpack
    SCHEMA pg_catalog
    VERSION "1.1";
